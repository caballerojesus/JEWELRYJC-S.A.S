package com.example.jewelryjcsas;

import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class Data {

    private static ArrayList<Order> Orders = new ArrayList<>();

    public static void Save(Order O){
        Orders.add(O);
    }

    public static ArrayList<Order> Get(){
        return Orders;
    }

    public static void Update(CheckBox Signature, EditText TxtSignature, Spinner JewelType,
                              Spinner Material, Spinner Stone, double P1, double P2,
                              TextView Price, double TotalPrice){
        if (Signature.isChecked()){
            TxtSignature.setVisibility(View.VISIBLE);
        }else{
            TxtSignature.setVisibility(View.INVISIBLE);
        }



        switch (JewelType.getSelectedItemPosition()){
            // select chain
            case 0:
                switch (Material.getSelectedItemPosition()){
                    case 0:
                        P1 = 100.000;
                        break;
                    case 1:
                        P1 = 50.000;
                        break;
                    case 2:
                        P1 = 150.000;
                        break;

                }

                switch (Stone.getSelectedItemPosition()){

                    case 0:
                        P2 = 190.000;
                        break;
                    case 1:
                        P2 = 180.000;
                        break;
                    case 2:
                        P2 = 150.000;
                        break;
                }
                break;

            // select brazalet
            case 1:
                switch (Material.getSelectedItemPosition()){
                    case 0:
                        P1 = 50.000;
                        break;
                    case 1:
                        P1 = 30.000;
                        break;
                    case 2:
                        P1 = 90.000;
                        break;

                }

                switch (Stone.getSelectedItemPosition()){
                    case 0:
                        P2 = 190.000;
                        break;
                    case 1:
                        P2 = 180.000;
                        break;
                    case 2:
                        P2 = 150.000;
                        break;
                }
                break;
        }


        DecimalFormat nume = new DecimalFormat("#.000");
        TotalPrice = P1 + P2;
        Price.setText("$COP " + nume.format(TotalPrice));
    }
}